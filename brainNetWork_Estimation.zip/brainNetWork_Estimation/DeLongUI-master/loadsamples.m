function samples = loadsamples(filename)

samples = load(filename);

end