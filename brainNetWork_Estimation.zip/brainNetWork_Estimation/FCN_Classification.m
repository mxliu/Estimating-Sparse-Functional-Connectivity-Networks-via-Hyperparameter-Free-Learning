clc
clear
%%================FCN PREPARATION and PARAMETRIC SELECTION==============%%
load('data.mat');
load('lab.mat');
root=cd; addpath(genpath([root '/DATA'])); addpath(genpath([root '/FUN']));
Popatient=size(find(lab==1),2);
Alpopu=size(lab,2);
nROI=size(data,1);
nSubj=length(lab);
kfold=nSubj; 
Test_res=zeros(1,nSubj); p_value=0.01;
%%====================FCN End==================%%
c=cvpartition(nSubj,'k',kfold);
% for i=1:nSubj
%                 originalNet = brainNetSet{5}(:,:,i);
%                 originalNet=originalNet-diag(diag(originalNet)); % remove the non-informative diagal elements
%                 originalNet=(originalNet+originalNet')/2; % symmetrization
%                 originalNet=triu(originalNet);
%                 data(:,i)=reshape(originalNet,nROI^2,1);
% end
% idx=find(sum(abs(data'))>1e-12); % for removing the trivial zero-rows
% data=data(idx,:);
 for f=1:c.NumTestSets
     Train_dat=data(:,training(c,f));
     Train_lab = lab(training(c,f));
     Test_dat = data(:,test(c,f));
     Test_lab = lab(test(c,f));
     [Index,~]=find(test(c,f)~=0);
     % t-test for feature selection
     POSITIVE_data = Train_dat(:,Train_lab==1);
     NEGATIVE_data = Train_dat(:,Train_lab==-1);       
     [tad,p_tmp] = ttest2(double(POSITIVE_data'), double(NEGATIVE_data'));
     [ordered_p,indp]=sort(p_tmp);
     index = indp(ordered_p<p_value);
     Train_dat = Train_dat(index,:);
     Test_dat = Test_dat(index,:);
    % scaling the data 
    MaxV=(max(Train_dat'))';
    MinV=(min(Train_dat'))';
    [R,C]= size(Train_dat);
    Train_dat=2*(Train_dat-repmat(MinV,1,C))./(repmat(MaxV,1,C)-repmat(MinV,1,C))-1;
    [R,C]= size(Test_dat);
    Test_dat=2*(Test_dat-repmat(MinV,1,C))./(repmat(MaxV,1,C)-repmat(MinV,1,C))-1;
    cmd = ['-t 0 -c 1 -b 1'];% linear kernel
    model = svmtrain(Train_lab', Train_dat', cmd); % Linear Kernel
    [predict_label, accuracy_svm, prob_estimates] = svmpredict(Test_lab', Test_dat', model, '-b 1');
    rating(:,Index)=prob_estimates;
    Test_res(Index) = sum(predict_label==Test_lab')/length(Test_lab);%accuracy;
    fprintf('current fold=%d.\n',f);
 end
[~,TP]=size(find(Test_res(:,1:Popatient)==1));
[~,FN]=size(find(Test_res(:,1:Popatient)==0));
[~,FP]=size(find(Test_res(:,Popatient+1:Alpopu)==0));
[~,TN]=size(find(Test_res(:,Popatient+1:Alpopu)==1));
ACC=mean(Test_res);SEN=TP/(TP+FN);
SPE=TN/(TN+FP);BAC=(sen+spe)*0.5;
PPV=TP/(TP+FP);NPV=TN/(TN+FN);