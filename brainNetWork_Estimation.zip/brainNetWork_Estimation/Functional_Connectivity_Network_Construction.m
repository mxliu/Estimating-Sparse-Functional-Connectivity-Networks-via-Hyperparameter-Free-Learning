%% The main procedure for construct brain networks based different methods
% The original ROI time series of all subjects with labels are stored in a mat file.
% For example, the file name of fMRI data is fMRI.mat where each subject
% corresponds to a cell, and in each cell a matrix is used to store the
% time series in its columns one by one. Also, the file include labels and
% subject index.
% method[1] is PC (Pearson's Correlaton);
% method[2] is SR (Sparse Representation based on Jun et al.'s SLEP);
% method[3] is The Proposed Method based on Lei sun
%Written by Lei Sun, 12/10/2019
%% basic setting, load data, basic statistics
clc;clear;
load ('data.mat');
load('E:\SUNlei\FirstPaper\ABIDEdata92\data\U.mat');
addpath('.\data'); addpath('.\Fun');clear data;
data=fmriMCINC;
load ('lab.mat');
root=cd; addpath(genpath([root '/DATA'])); addpath(genpath([root '/FUN']));
nSubj=length(lab);
Ntime=size(data{1},1);nROI=size(data{1},2);
method=input('PCC[1],SR[2],The Proposed Method[3]:');
%% Network learning based on Pearson's correlation (including sparsification with different thresholds)
if method==1
    lambda=[0 10 20 30 40  50 60 70  80 90  99] % the values lies in [0,100] denoting the sparsity degree
    disp('Press any key:'); pause;
    nPar=length(lambda);
    brainNetSet=cell(1,nPar);
    for L=1:nPar
        brainNet=zeros(nROI,nROI,nSubj);
        for i=1:nSubj
            currentNet=corrcoef(data{i});
            currentNet=currentNet-diag(diag(currentNet));% no link to oneself
            threhold=prctile(abs(currentNet(:)),lambda(L)); % fractile quantile
            currentNet(find(abs(currentNet)<=threhold))=0;
            brainNet(:,:,i)=currentNet;
        end
        brainNetSet{L}=brainNet;
        fprintf('Done %d/%d networks!\n',L,nPar);
    end
    save('brainNetSet_PC.mat','brainNetSet','lab');
end
%% Network learning based on sparse representation(SR) - SLEP
if method==2
    %Parameter setting for SLEP
   ex=-5:5;
   lambda=2.^ex;
%lambda=[0.1,0.11,0.12,0.13,0.14,0.15,0.16,0.17,0.18,0.19];
    disp('Press any key:'); pause;
    nPar=length(lambda);
    brainNetSet=cell(1,nPar);
    opts=[];
    opts.init=2;% Starting point: starting from a zero point here
    opts.tFlag=0;% termination criterion
    opts.nFlag=0;% normalization option: 0-without normalization
    opts.rFlag=0;% regularization % the input parameter 'rho' is a ratio in (0, 1)
    opts.rsL2=0; % the squared two norm term in min  1/2 || A x - y||^2 + 1/2 rsL2 * ||x||_2^2 + z * ||x||_1
    fprintf('\n mFlag=0, lFlag=0 \n');
    opts.mFlag=0;% treating it as compositive function
    opts.lFlag=0;% Nemirovski's line search
    for L=1:nPar
        brainNet=zeros(nROI,nROI,nSubj);
        for i=1:nSubj
            tmp=data{i};
            tmp=tmp-repmat(mean(tmp),Ntime,1);
            currentNet=zeros(nROI,nROI);
            for j=1:nROI
                y=[tmp(:,j)];
                A=[tmp(:,setdiff(1:nROI,j))];
                [x, funVal1, ValueL1]= LeastR(A, y, lambda(L), opts);
                currentNet(setdiff(1:nROI,j),j) = x;
            end
            brainNet(:,:,i)=currentNet;
        end
        brainNetSet{L}=brainNet;
        fprintf('Done %d/%d networks!\n',L,nPar);
    end
    save('brainNetSet_SR.mat','brainNetSet','lab');
end
%% Network Learning based on The Proposed Method
if method==3
    %%====Value setting for The Proposed Method.====%%
    %% specific symbolic details are shown in APPENDIX of our paper.
    nSubj=length(lab);nROI=size(data{1},2);
    Poedge=(nROI*(nROI-1))/2;
    BrainNetSet=zeros(Poedge,nSubj);
    Newdata=cell(1,nSubj);
    A=[-abs(U);-eye(Poedge)];
    b=[-ones(nROI,1);zeros(Poedge,1)];
    original_work=zeros(Poedge,1);
    M=zeros(Poedge,nROI*Ntime);
    %%===================End====================%%
 for L=1:nSubj
      data{L}=zscore(data{L});%% The obtained data were normalized.
      currentdata=data{L}';
 for i=1:Ntime
    y=U'*currentdata(:,i);
    Y=diag(y);
    Matrix=Y*U';
    M(:,nROI*(i-1)+1:nROI*i)=Matrix(:,1:116);
end
  M=M';
    cvx_begin  
    variable original_work(Poedge);
    minimize(norm(M*original_work));
    subject to
    A*original_work<=b; %%constraints used in our paper.
    cvx_end
    BrainNetSet(:,L)=original_work;
 end
save('brainNetSet_TPM','BrainNetSet','lab');
end
 
